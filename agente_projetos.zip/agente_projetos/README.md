# Assistente de Projetos (Python, gratuito)

Agente que ajuda a acompanhar projetos: status, gargalos, pendências, atas e alertas.
Usa dados **fictícios** para teste, IA **gratuita**, Telegram e Whisper.

## Arquivos principais
| Arquivo | Para que serve |
|---|---|
| `gerar_dados_falsos.py` | Cria projetos e atas fictícios |
| `status.py` | Calcula semáforo, atrasos, bloqueios e próximos passos (sem IA) |
| `painel.py` | Painel visual (Streamlit) |
| `agente.py` | Agente no terminal com IA gratuita (Ollama, Gemini ou Groq) |
| `telegram_bot.py` | O mesmo agente, conversando pelo Telegram, com botões de confirmação |
| `resumo_diario.py` | "Bom dia, Projetos" enviado ao seu Telegram |
| `transcrever.py` | Áudio de reunião -> texto (Whisper local) na pasta `entrada/` |
| `agente_claude.py` | Opcional: mesma ideia com a API do Claude (paga) |
| `.github/workflows/resumo_diario.yml` | Roda o resumo sozinho toda manhã (GitHub Actions) |

## Passo a passo
1. `pip install -r requirements.txt`
2. `python gerar_dados_falsos.py`
3. Painel (sem chave, sem custo): `streamlit run painel.py`
4. IA gratuita: instale o [Ollama](https://ollama.com), rode `ollama pull llama3.1`,
   copie `.env.example` para `.env` e rode `python agente.py`
5. Telegram: crie um bot com o @BotFather, coloque o token no `.env`,
   rode `python telegram_bot.py`, mande uma mensagem ao bot, copie o chat_id que ele
   responder para `TELEGRAM_CHAT_ID` e reinicie.
6. Whisper: `pip install faster-whisper` e depois `python transcrever.py reuniao.mp3`
7. Pergunte ao agente: "Há materiais novos? Leia e diga a qual projeto cada um pertence."

## Resumo automático toda manhã (GitHub Actions)
No repositório: Settings > Secrets and variables > Actions > New repository secret.
Crie `TELEGRAM_BOT_TOKEN` e `TELEGRAM_CHAT_ID`. Depois, em Actions, rode o workflow
uma vez na mão ("Run workflow") para testar. Horário: 08:00 de São Paulo, segunda a sexta.
Observações do GitHub: o horário pode atrasar alguns minutos, e em repositório público
o agendamento é desativado após 60 dias sem atividade (reative na aba Actions).

## Segurança
- Nunca suba o arquivo `.env` (já está no `.gitignore`).
- Se o token do bot vazar, gere outro no @BotFather (`/revoke`).
- O bot só responde ao `TELEGRAM_CHAT_ID` configurado.
- O agente sempre pede confirmação antes de criar pasta, salvar arquivo ou enviar alerta.
