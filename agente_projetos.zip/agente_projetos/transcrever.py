"""
transcrever.py
--------------
Transforma o áudio de uma reunião em texto usando o Whisper (gratuito, roda no
seu computador, sem enviar o áudio para a internet). O resultado vai para a pasta
'entrada/', pronto para o agente classificar e (com a sua confirmação) arquivar.

Instalação (uma vez):  pip install faster-whisper
Uso:  python transcrever.py reuniao.mp3
      python transcrever.py reuniao.mp3 --modelo small

Modelos: tiny (rápido, menos preciso) | base | small (bom equilíbrio) | medium.
Na primeira execução o modelo é baixado automaticamente.
IMPORTANTE: a transcrição automática pode errar nomes e termos técnicos. Revise.
"""

import argparse
from pathlib import Path


def transcrever(audio: Path, modelo: str = "small") -> Path:
    from faster_whisper import WhisperModel  # importa só aqui: é uma biblioteca pesada

    whisper = WhisperModel(modelo, device="cpu", compute_type="int8")
    trechos, info = whisper.transcribe(str(audio), language="pt")
    texto = "\n".join(t.text.strip() for t in trechos)

    saida = Path("entrada") / f"ata_{audio.stem}.txt"
    saida.parent.mkdir(exist_ok=True)
    saida.write_text(
        f"TRANSCRIÇÃO AUTOMÁTICA (Whisper, modelo {modelo}) - revise antes de usar\n"
        f"Arquivo de origem: {audio.name}\n\n{texto}\n", encoding="utf-8")
    return saida


def main():
    p = argparse.ArgumentParser(description="Transcreve áudio de reunião para a pasta entrada/")
    p.add_argument("audio", type=Path, help="arquivo de áudio ou vídeo (mp3, wav, m4a, mp4...)")
    p.add_argument("--modelo", default="small", choices=["tiny", "base", "small", "medium"])
    a = p.parse_args()
    if not a.audio.exists():
        raise SystemExit(f"Arquivo não encontrado: {a.audio}")
    print("Transcrevendo (pode levar alguns minutos)...")
    print("Pronto:", transcrever(a.audio, a.modelo))


if __name__ == "__main__":
    main()
