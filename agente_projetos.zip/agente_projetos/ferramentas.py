"""
ferramentas.py
--------------
Funções que o agente pode "chamar". Cada função faz UMA coisa simples.

- Dados dos projetos: FONTE_DADOS=arquivo (dados fictícios, padrão) ou
  FONTE_DADOS=azure (Azure DevOps real, precisa de um token PAT).
- Pastas dos projetos: ficam no seu computador (pasta ./projetos).
- Atas/emails novos: arquivos .txt na pasta ./entrada (inclusive as
  transcrições geradas pelo Whisper).
- Alertas: Telegram. Sem configuração, só simula.
- Tudo que SALVA ou ENVIA pede a sua confirmação (terminal ou botões do Telegram).
"""

import os
import re
from pathlib import Path

import requests

import canal_telegram
import status

PASTA_PROJETOS = Path("projetos")
PASTA_ENTRADA = Path("entrada")
SUBPASTAS = ["atas", "emails", "teams", "status"]


# ---------- utilidades ----------

def _nome_seguro(texto: str) -> str:
    """Remove caracteres perigosos de nomes de pasta/arquivo (evita '../')."""
    texto = re.sub(r"[^\w\- .]", "", texto, flags=re.UNICODE).strip()
    if not texto or texto.startswith("."):
        raise ValueError(f"Nome inválido: {texto!r}")
    return texto


def _confirmar_no_terminal(pergunta: str) -> bool:
    resposta = input(f"\n[CONFIRMAÇÃO] {pergunta} (s/n): ").strip().lower()
    return resposta in ("s", "sim")


# Quem pergunta "posso?" pode ser trocado: terminal (padrão) ou Telegram.
_confirmador = _confirmar_no_terminal


def definir_confirmador(funcao):
    """Troca a forma de pedir confirmação (usado pelo bot do Telegram)."""
    global _confirmador
    _confirmador = funcao


def _confirmar(pergunta: str) -> bool:
    return _confirmador(pergunta)


# ---------- itens dos projetos ----------

def buscar_itens_projeto(projeto: str, apenas_abertos: bool = True) -> str:
    """Busca os itens (tarefas, bugs, histórias) de um projeto."""
    if os.getenv("FONTE_DADOS", "arquivo") == "azure":
        return _buscar_azure(projeto, apenas_abertos)
    return _buscar_arquivo(projeto, apenas_abertos)


def _buscar_arquivo(projeto: str, apenas_abertos: bool) -> str:
    """Lê os dados fictícios de dados_falsos/itens.json."""
    itens = [i for i in status.carregar_itens() if i["projeto"] == projeto]
    if apenas_abertos:
        itens = [i for i in itens if i["estado"] not in status.ENCERRADOS]
    if not itens:
        return "Nenhum item encontrado (confira o nome do projeto com listar_projetos)."
    linhas = []
    for i in itens:
        bloqueio = f" | BLOQUEADO: {i['motivo_bloqueio']}" if i["bloqueado"] else ""
        linhas.append(
            f"#{i['id']} | {i['tipo']} | {i['estado']} | {i['titulo']} | "
            f"{i['responsavel'] or 'sem responsável'} | prazo: {i['prazo']}{bloqueio}"
        )
    return "\n".join(linhas)


def _buscar_azure(projeto: str, apenas_abertos: bool) -> str:
    """Busca work items no Azure DevOps real (FONTE_DADOS=azure)."""
    org = os.environ["AZDO_ORG"]
    pat = os.environ["AZDO_PAT"]
    base = f"https://dev.azure.com/{org}/{projeto}/_apis"
    auth = ("", pat)  # usuário vazio + PAT como senha

    filtro = "AND [System.State] NOT IN ('Done','Closed','Removed')" if apenas_abertos else ""
    wiql = {
        "query": (
            "SELECT [System.Id] FROM WorkItems "
            f"WHERE [System.TeamProject] = '{projeto}' {filtro} "
            "ORDER BY [System.ChangedDate] DESC"
        )
    }
    r = requests.post(f"{base}/wit/wiql?api-version=7.1", json=wiql, auth=auth, timeout=30)
    r.raise_for_status()
    ids = [str(i["id"]) for i in r.json().get("workItems", [])][:50]
    if not ids:
        return "Nenhum item encontrado."

    campos = ",".join([
        "System.Id", "System.Title", "System.State", "System.WorkItemType",
        "System.AssignedTo", "Microsoft.VSTS.Scheduling.TargetDate", "System.Tags",
    ])
    r = requests.get(
        f"{base}/wit/workitems?ids={','.join(ids)}&fields={campos}&api-version=7.1",
        auth=auth, timeout=30,
    )
    r.raise_for_status()

    linhas = []
    for item in r.json()["value"]:
        f = item["fields"]
        responsavel = f.get("System.AssignedTo", {}).get("displayName", "sem responsável")
        linhas.append(
            f"#{f['System.Id']} | {f['System.WorkItemType']} | {f['System.State']} | "
            f"{f['System.Title']} | {responsavel} | prazo: "
            f"{f.get('Microsoft.VSTS.Scheduling.TargetDate', 'sem prazo')} | "
            f"tags: {f.get('System.Tags', '-')}"
        )
    return "\n".join(linhas)


# ---------- pastas dos projetos ----------

def listar_projetos() -> str:
    """Lista os projetos existentes e indica quais já têm pasta."""
    if os.getenv("FONTE_DADOS", "arquivo") == "arquivo":
        nomes = sorted({i["projeto"] for i in status.carregar_itens()})
        return "\n".join(
            f"{n} ({'pasta criada' if (PASTA_PROJETOS / n).exists() else 'sem pasta'})"
            for n in nomes)
    if not PASTA_PROJETOS.exists():
        return "Nenhum projeto criado ainda."
    nomes = sorted(p.name for p in PASTA_PROJETOS.iterdir() if p.is_dir())
    return "\n".join(nomes) if nomes else "Nenhum projeto criado ainda."


def criar_pasta_projeto(projeto: str) -> str:
    """Cria a pasta do projeto com as subpastas padrão (após confirmação)."""
    projeto = _nome_seguro(projeto)
    if not _confirmar(f"Criar a pasta do projeto '{projeto}'?"):
        return "A usuária não autorizou. Nada foi criado."
    for sub in SUBPASTAS:
        (PASTA_PROJETOS / projeto / sub).mkdir(parents=True, exist_ok=True)
    return f"Pasta criada em {PASTA_PROJETOS / projeto}"


# ---------- atas e materiais novos ----------

def listar_materiais_novos() -> str:
    """Lista arquivos .txt/.md na pasta 'entrada' (atas, emails, transcrições)."""
    PASTA_ENTRADA.mkdir(exist_ok=True)
    arquivos = sorted(p.name for p in PASTA_ENTRADA.iterdir() if p.suffix in (".txt", ".md"))
    return "\n".join(arquivos) if arquivos else "Nenhum material novo na pasta 'entrada'."


def ler_material(nome_arquivo: str) -> str:
    """Lê o conteúdo de um arquivo da pasta 'entrada'."""
    caminho = PASTA_ENTRADA / _nome_seguro(nome_arquivo)
    return caminho.read_text(encoding="utf-8")[:20000]


def salvar_na_pasta_do_projeto(projeto: str, tipo: str, nome_arquivo: str, conteudo: str) -> str:
    """Salva um material na pasta do projeto (após confirmação do material E do projeto)."""
    projeto = _nome_seguro(projeto)
    nome_arquivo = _nome_seguro(nome_arquivo)
    if tipo not in SUBPASTAS:
        return f"Tipo inválido. Use um destes: {', '.join(SUBPASTAS)}"

    destino = PASTA_PROJETOS / projeto / tipo / nome_arquivo
    if not (PASTA_PROJETOS / projeto).exists():
        return f"O projeto '{projeto}' não tem pasta. Crie com criar_pasta_projeto."
    if destino.exists():
        return "Esse arquivo já existe na pasta. Nada foi alterado."

    previa = conteudo[:300].replace("\n", " ")
    if not _confirmar(f"Salvar '{nome_arquivo}' no projeto '{projeto}' (pasta {tipo})?\n"
                      f"Prévia: {previa}..."):
        return "A usuária não autorizou. Nada foi salvo."
    destino.write_text(conteudo, encoding="utf-8")
    return f"Salvo em {destino}"


# ---------- alertas (Telegram) ----------

def enviar_alerta(mensagem: str) -> str:
    """Envia um alerta ao grupo (após mostrar o texto e receber confirmação)."""
    if not _confirmar(f"Enviar este alerta ao grupo?\n\n{mensagem}"):
        return "A usuária não autorizou. Nenhum alerta foi enviado."
    destino = os.getenv("TELEGRAM_ALERTA_CHAT_ID") or os.getenv("TELEGRAM_CHAT_ID")
    if not (os.getenv("TELEGRAM_BOT_TOKEN") and destino):
        return "Modo simulação: Telegram não configurado, nada foi enviado de verdade."
    canal_telegram.enviar(destino, "🚨 " + mensagem)
    return "Alerta enviado ao grupo."
