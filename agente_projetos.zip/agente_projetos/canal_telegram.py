"""
canal_telegram.py
-----------------
Conversa com o Telegram usando só a biblioteca 'requests' (sem instalar nada extra).

Como criar o seu bot (gratuito):
1. No Telegram, procure por @BotFather e envie /newbot
2. Escolha um nome e guarde o TOKEN que ele devolver
3. Coloque o token em TELEGRAM_BOT_TOKEN no arquivo .env
"""

import os

import requests

API = os.getenv("TELEGRAM_API_URL", "https://api.telegram.org")


def chamar(metodo: str, **parametros):
    """Chama um método da API do Telegram e devolve o resultado."""
    token = os.environ["TELEGRAM_BOT_TOKEN"]
    r = requests.post(f"{API}/bot{token}/{metodo}", json=parametros, timeout=70)
    r.raise_for_status()
    return r.json()["result"]


def enviar(chat_id, texto: str, botoes=None):
    """Envia uma mensagem. 'botoes' é uma lista como [("✅ Sim", "sim"), ("❌ Não", "nao")]."""
    parametros = {"chat_id": chat_id, "text": texto[:4000]}  # limite do Telegram: 4096
    if botoes:
        parametros["reply_markup"] = {
            "inline_keyboard": [[{"text": t, "callback_data": d} for t, d in botoes]]
        }
    return chamar("sendMessage", **parametros)


def buscar_atualizacoes(offset=None, espera=30):
    """Pergunta ao Telegram se há mensagens novas (espera até 'espera' segundos)."""
    parametros = {"timeout": espera, "allowed_updates": ["message", "callback_query"]}
    if offset is not None:
        parametros["offset"] = offset
    return chamar("getUpdates", **parametros)
