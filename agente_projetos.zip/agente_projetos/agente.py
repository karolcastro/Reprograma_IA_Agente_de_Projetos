"""
agente.py  (versão GRATUITA)
----------------------------
O "cérebro" do agente usando qualquer IA que fale o formato "OpenAI-compatível".
Isso inclui modelos GRATUITOS:

  1) Ollama (roda no seu computador, 100% grátis)  <- padrão
       - instale em ollama.com e rode:  ollama pull llama3.1
  2) Google Gemini (API com camada gratuita)
       LLM_BASE_URL=https://generativelanguage.googleapis.com/v1beta/openai
       LLM_MODEL=gemini-2.0-flash   LLM_API_KEY=sua-chave
  3) Groq (API com camada gratuita)
       LLM_BASE_URL=https://api.groq.com/openai/v1
       LLM_MODEL=llama-3.3-70b-versatile   LLM_API_KEY=sua-chave

(Limites e nomes de modelos gratuitos mudam: confira no site de cada serviço.)

Como rodar no terminal:  python agente.py
"""

import json
import os
from pathlib import Path

import requests
from dotenv import load_dotenv

import ferramentas as f
from catalogo import FERRAMENTAS, executar

load_dotenv()

URL = os.getenv("LLM_BASE_URL", "http://localhost:11434/v1").rstrip("/")
MODELO = os.getenv("LLM_MODEL", "llama3.1")
CHAVE = os.getenv("LLM_API_KEY", "ollama")  # o Ollama ignora a chave
INSTRUCOES = Path(__file__).with_name("prompt_do_agente.md").read_text(encoding="utf-8")

# Converte o catálogo para o formato de ferramentas que o provedor entende
FERRAMENTAS_API = [
    {"type": "function", "function": {
        "name": t["nome"], "description": t["descricao"],
        "parameters": {"type": "object", "properties": t["propriedades"],
                       "required": t["obrigatorios"]}}}
    for t in FERRAMENTAS
]


def responder(historico, max_voltas=8):
    """Pergunta à IA. Se ela pedir ferramentas, executa e continua até ela terminar."""
    for _ in range(max_voltas):
        mensagens = [{"role": "system", "content": INSTRUCOES}] + historico
        r = requests.post(
            f"{URL}/chat/completions",
            headers={"Authorization": f"Bearer {CHAVE}"},
            json={"model": MODELO, "messages": mensagens, "tools": FERRAMENTAS_API},
            timeout=300,
        )
        r.raise_for_status()
        msg = r.json()["choices"][0]["message"]
        historico.append({"role": "assistant", "content": msg.get("content") or "",
                          **({"tool_calls": msg["tool_calls"]} if msg.get("tool_calls") else {})})

        if not msg.get("tool_calls"):
            return msg.get("content") or "(sem resposta)"

        for chamada in msg["tool_calls"]:
            nome = chamada["function"]["name"]
            argumentos = chamada["function"].get("arguments") or {}
            if isinstance(argumentos, str):  # a maioria dos provedores manda texto JSON
                try:
                    argumentos = json.loads(argumentos or "{}")
                except json.JSONDecodeError:
                    argumentos = {}
            print(f"  (usando ferramenta: {nome})")
            historico.append({"role": "tool", "tool_call_id": chamada.get("id", nome),
                              "content": executar(nome, argumentos)})
    return "Não consegui concluir o pedido. Tente reformular de forma mais simples."


def main():
    print(f"Assistente de Projetos | modelo: {MODELO} (digite 'sair' para encerrar)")
    historico = []
    while True:
        pergunta = input("\nVocê: ").strip()
        if pergunta.lower() in ("sair", "exit"):
            break
        if not pergunta:
            continue
        historico.append({"role": "user", "content": pergunta})
        try:
            print("\nAgente:", responder(historico))
        except requests.RequestException as erro:
            print("\nNão consegui falar com a IA. Ela está rodando?", erro)
            historico.pop()


if __name__ == "__main__":
    main()
