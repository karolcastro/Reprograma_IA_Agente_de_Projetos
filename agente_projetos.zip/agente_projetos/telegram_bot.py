"""
telegram_bot.py
---------------
Conversa com o agente pelo Telegram. As confirmações viram BOTÕES (✅ Sim / ❌ Não).

Como usar:
1. Crie o bot no @BotFather e coloque TELEGRAM_BOT_TOKEN no .env
2. Rode:  python telegram_bot.py
3. Mande qualquer mensagem ao seu bot: ele responde com o seu chat_id.
   Coloque em TELEGRAM_CHAT_ID no .env e reinicie.
   (A partir daí, o bot ignora qualquer outra pessoa.)
"""

import os
import time

import requests
from dotenv import load_dotenv

load_dotenv()

import agente  # noqa: E402  (precisa vir depois do load_dotenv)
import canal_telegram as tg  # noqa: E402
import ferramentas as f  # noqa: E402

CHAT = os.environ.get("TELEGRAM_CHAT_ID", "")
estado = {"offset": None}
historico = []


def confirmar_pelo_telegram(pergunta: str) -> bool:
    """Envia a pergunta com botões e espera até 5 minutos pelo seu clique."""
    tg.enviar(CHAT, "🔔 " + pergunta, [("✅ Sim", "sim"), ("❌ Não", "nao")])
    limite = time.time() + 300
    while time.time() < limite:
        for u in tg.buscar_atualizacoes(estado["offset"], espera=10):
            estado["offset"] = u["update_id"] + 1
            clique = u.get("callback_query")
            if clique and str(clique["message"]["chat"]["id"]) == CHAT:
                tg.chamar("answerCallbackQuery", callback_query_id=clique["id"])
                return clique["data"] == "sim"
    tg.enviar(CHAT, "⏱️ Sem resposta em 5 minutos. Cancelei a ação.")
    return False


def _aparar(h, maximo=40):
    """Mantém o histórico curto, cortando sempre no começo de uma pergunta sua."""
    if len(h) <= maximo:
        return
    for i in range(len(h) - 20, len(h)):
        if h[i]["role"] == "user" and isinstance(h[i]["content"], str):
            del h[:i]
            return


def main(max_ciclos=None):
    f.definir_confirmador(confirmar_pelo_telegram)
    print("Bot rodando. Pare com Ctrl+C.")
    ciclos = 0
    while max_ciclos is None or ciclos < max_ciclos:
        ciclos += 1
        try:
            novidades = tg.buscar_atualizacoes(estado["offset"])
        except requests.RequestException as erro:
            print("Falha de rede:", erro)
            time.sleep(5)
            continue
        for u in novidades:
            estado["offset"] = u["update_id"] + 1
            msg = u.get("message")
            if not msg or "text" not in msg:
                continue
            chat = str(msg["chat"]["id"])
            if not CHAT:
                tg.enviar(chat, f"Seu chat_id é {chat}. Coloque em TELEGRAM_CHAT_ID no .env e reinicie o bot.")
                continue
            if chat != CHAT:
                continue  # ignora estranhos
            if msg["text"].strip() == "/limpar":
                historico.clear()
                tg.enviar(chat, "Conversa reiniciada.")
                continue
            tg.enviar(chat, "⏳ Pensando...")
            historico.append({"role": "user", "content": msg["text"]})
            try:
                resposta = agente.responder(historico)
            except Exception as erro:
                resposta = f"Tive um problema: {erro}"
            tg.enviar(chat, resposta)
            _aparar(historico)


if __name__ == "__main__":
    main()
