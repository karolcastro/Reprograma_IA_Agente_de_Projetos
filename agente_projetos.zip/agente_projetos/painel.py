"""
painel.py
---------
Painel de status dos projetos (front end).

Como rodar:  streamlit run painel.py
"""

import pandas as pd
import streamlit as st

import status

st.set_page_config(page_title="Assistente de Projetos", layout="wide")
st.title("Assistente de Projetos")
st.caption("Dados fictícios para teste")

itens = status.carregar_itens()
projetos = sorted({i["projeto"] for i in itens})

# Visão geral: um cartão por projeto
cores = {"verde": "🟢", "amarelo": "🟡", "vermelho": "🔴"}
colunas = st.columns(len(projetos))
resumos = {}
for coluna, nome in zip(colunas, projetos):
    r = status.analisar([i for i in itens if i["projeto"] == nome])
    resumos[nome] = r
    with coluna:
        st.subheader(f"{cores[r['semaforo']]} {nome}")
        st.write(f"{r['concluidos']}/{r['total']} concluídos")
        st.write(f"Atrasados: {len(r['atrasados'])} | Bloqueados: {len(r['bloqueados'])}")

st.divider()

# Detalhe do projeto escolhido
escolhido = st.selectbox("Escolha um projeto", projetos)
r = resumos[escolhido]


def tabela(lista, colunas_extra=()):
    if not lista:
        st.write("Nada por aqui.")
        return
    cols = ["id", "titulo", "estado", "responsavel", "prazo", *colunas_extra]
    st.dataframe(pd.DataFrame(lista)[cols], hide_index=True, width="stretch")


aba1, aba2, aba3, aba4, aba5 = st.tabs(
    ["Atividades", "Pendências", "Gargalos", "Próximos passos", "Alertas"])

with aba1:
    st.write("Itens em andamento")
    tabela(r["em_andamento"])
with aba2:
    st.write("Itens atrasados")
    tabela(r["atrasados"])
    st.write("Itens sem responsável")
    tabela(r["sem_responsavel"])
with aba3:
    st.write("Itens bloqueados")
    tabela(r["bloqueados"], ("motivo_bloqueio",))
with aba4:
    st.write("Próximos 5 itens por prazo")
    tabela(r["proximos_passos"])
with aba5:
    st.write("Texto sugerido para o grupo de alertas (você decide se envia)")
    texto = (f"Projeto {escolhido}: {len(r['atrasados'])} itens atrasados, "
             f"{len(r['bloqueados'])} bloqueados. Precisamos de atenção.")
    st.code(texto)
