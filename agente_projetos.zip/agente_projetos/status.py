"""
status.py
---------
Calcula o status de cada projeto com REGRAS simples (sem IA, sem custo).
É usado pelo painel (painel.py) e pelo agente.
"""

import json
from datetime import date
from pathlib import Path

ARQUIVO = Path("dados_falsos/itens.json")
ENCERRADOS = ("Done", "Closed", "Removed")


def carregar_itens():
    if not ARQUIVO.exists():
        raise FileNotFoundError("Rode primeiro: python gerar_dados_falsos.py")
    return json.loads(ARQUIVO.read_text(encoding="utf-8"))


def analisar(itens_do_projeto):
    """Recebe a lista de itens de UM projeto e devolve o resumo."""
    hoje = date.today()
    abertos = [i for i in itens_do_projeto if i["estado"] not in ENCERRADOS]
    atrasados = [i for i in abertos if date.fromisoformat(i["prazo"]) < hoje]
    bloqueados = [i for i in abertos if i["bloqueado"]]
    sem_resp = [i for i in abertos if not i["responsavel"]]
    em_andamento = [i for i in abertos if i["estado"] == "Active"]
    proximos = sorted(abertos, key=lambda i: i["prazo"])[:5]

    if len(bloqueados) >= 2 or len(atrasados) >= 3:
        semaforo = "vermelho"
    elif bloqueados or atrasados or sem_resp:
        semaforo = "amarelo"
    else:
        semaforo = "verde"

    return {
        "semaforo": semaforo,
        "total": len(itens_do_projeto),
        "concluidos": len(itens_do_projeto) - len(abertos),
        "em_andamento": em_andamento,
        "atrasados": atrasados,
        "bloqueados": bloqueados,
        "sem_responsavel": sem_resp,
        "proximos_passos": proximos,
    }
