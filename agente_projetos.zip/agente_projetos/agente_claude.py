"""
agente_claude.py  (opcional, PAGO por uso)
------------------------------------------
Mesma ideia do agente.py, mas usando a API do Claude (precisa de ANTHROPIC_API_KEY
e pip install anthropic). Útil para comparar a qualidade com o modelo gratuito.
"""

import os
from pathlib import Path

from anthropic import Anthropic
from dotenv import load_dotenv

from catalogo import FERRAMENTAS, executar

load_dotenv()
client = Anthropic()
MODELO = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")
INSTRUCOES = Path(__file__).with_name("prompt_do_agente.md").read_text(encoding="utf-8")

FERRAMENTAS_API = [
    {"name": t["nome"], "description": t["descricao"],
     "input_schema": {"type": "object", "properties": t["propriedades"],
                      "required": t["obrigatorios"]}}
    for t in FERRAMENTAS
]


def responder(historico):
    while True:
        resposta = client.messages.create(
            model=MODELO, max_tokens=2000, system=INSTRUCOES,
            tools=FERRAMENTAS_API, messages=historico)
        historico.append({"role": "assistant", "content": resposta.content})
        if resposta.stop_reason != "tool_use":
            return "".join(b.text for b in resposta.content if b.type == "text")
        resultados = []
        for bloco in resposta.content:
            if bloco.type == "tool_use":
                print(f"  (usando ferramenta: {bloco.name})")
                resultados.append({"type": "tool_result", "tool_use_id": bloco.id,
                                   "content": executar(bloco.name, bloco.input)})
        historico.append({"role": "user", "content": resultados})


def main():
    print("Assistente de Projetos com Claude (digite 'sair' para encerrar)")
    historico = []
    while True:
        pergunta = input("\nVocê: ").strip()
        if pergunta.lower() in ("sair", "exit"):
            break
        if pergunta:
            historico.append({"role": "user", "content": pergunta})
            print("\nAgente:", responder(historico))


if __name__ == "__main__":
    main()
