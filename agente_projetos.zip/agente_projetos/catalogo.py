"""
catalogo.py
-----------
O "cardápio" de ferramentas do agente: nome, descrição e parâmetros de cada uma.
Os agentes (agente.py e agente_claude.py) convertem este cardápio para o formato
que cada provedor de IA entende.
"""

import ferramentas as f

TEXTO = {"type": "string"}


def _tool(nome, descricao, propriedades, obrigatorios):
    return {"nome": nome, "descricao": descricao,
            "propriedades": propriedades, "obrigatorios": obrigatorios}


FERRAMENTAS = [
    _tool("listar_projetos", "Lista os projetos e informa quais já têm pasta.", {}, []),
    _tool("buscar_itens_projeto",
          "Busca os itens de um projeto (para status, gargalos, pendências).",
          {"projeto": TEXTO, "apenas_abertos": {"type": "boolean"}}, ["projeto"]),
    _tool("criar_pasta_projeto",
          "Cria a pasta de um projeto com subpastas atas, emails, teams e status. Pede confirmação.",
          {"projeto": TEXTO}, ["projeto"]),
    _tool("listar_materiais_novos",
          "Lista atas, emails e transcrições novas aguardando classificação.", {}, []),
    _tool("ler_material", "Lê o conteúdo de um material novo.",
          {"nome_arquivo": TEXTO}, ["nome_arquivo"]),
    _tool("salvar_na_pasta_do_projeto",
          "Salva um material na pasta do projeto. Pede confirmação à usuária.",
          {"projeto": TEXTO,
           "tipo": {"type": "string", "enum": f.SUBPASTAS},
           "nome_arquivo": TEXTO,
           "conteudo": TEXTO},
          ["projeto", "tipo", "nome_arquivo", "conteudo"]),
    _tool("enviar_alerta", "Envia um alerta ao grupo. Pede confirmação à usuária.",
          {"mensagem": TEXTO}, ["mensagem"]),
]

# Liga o nome da ferramenta à função Python real
FUNCOES = {
    "listar_projetos": f.listar_projetos,
    "buscar_itens_projeto": f.buscar_itens_projeto,
    "criar_pasta_projeto": f.criar_pasta_projeto,
    "listar_materiais_novos": f.listar_materiais_novos,
    "ler_material": f.ler_material,
    "salvar_na_pasta_do_projeto": f.salvar_na_pasta_do_projeto,
    "enviar_alerta": f.enviar_alerta,
}


def executar(nome, argumentos):
    """Roda a ferramenta pedida pela IA. Erros viram texto para a IA explicar."""
    if nome not in FUNCOES:
        return f"Ferramenta desconhecida: {nome}"
    try:
        return str(FUNCOES[nome](**argumentos))
    except Exception as erro:
        return f"Erro ao executar {nome}: {erro}"
