"""
gerar_dados_falsos.py
---------------------
Cria dados FICTÍCIOS para você testar o agente sem nenhum sistema real:
- dados_falsos/itens.json  -> itens de trabalho (como seriam no Azure DevOps)
- entrada/*.txt            -> atas e emails de exemplo

Os prazos são calculados a partir de HOJE, então sempre haverá itens
atrasados e bloqueados para o agente encontrar.

Rode:  python gerar_dados_falsos.py
"""

import json
from datetime import date, timedelta
from pathlib import Path

HOJE = date.today()

# (projeto, tipo, título, estado, responsável, dias até o prazo, bloqueado?, motivo)
ITENS = [
    # --- Migração CRM ---
    ("Migração CRM", "Tarefa", "Mapear campos do sistema antigo", "Done", "Ana Souza", -20, False, ""),
    ("Migração CRM", "Tarefa", "Limpar base de clientes duplicados", "Active", "Bruno Lima", -3, False, ""),
    ("Migração CRM", "Bug", "Erro na importação de contatos", "Active", "Bruno Lima", -1, True, "Aguardando resposta do fornecedor"),
    ("Migração CRM", "Tarefa", "Configurar integração com ERP", "New", "", 10, False, ""),
    ("Migração CRM", "História", "Treinamento da equipe comercial", "New", "Carla Dias", 25, False, ""),
    ("Migração CRM", "Tarefa", "Plano de rollback", "Active", "Ana Souza", 5, False, ""),
    ("Migração CRM", "Tarefa", "Testes de aceitação (UAT)", "New", "Carla Dias", 18, True, "Depende da integração com ERP"),
    # --- Implantação Service Desk ---
    ("Implantação Service Desk", "Tarefa", "Definir catálogo de serviços", "Done", "Diego Rocha", -15, False, ""),
    ("Implantação Service Desk", "Tarefa", "Configurar fluxos de aprovação", "Active", "Elisa Prado", 2, False, ""),
    ("Implantação Service Desk", "História", "Migrar chamados abertos", "Active", "Diego Rocha", -2, False, ""),
    ("Implantação Service Desk", "Tarefa", "Criar base de conhecimento", "New", "", 14, False, ""),
    ("Implantação Service Desk", "Tarefa", "Integrar com diretório de usuários", "Active", "Elisa Prado", 7, False, ""),
    ("Implantação Service Desk", "Tarefa", "Homologar relatórios de SLA", "New", "Diego Rocha", 20, False, ""),
    # --- Portal do Fornecedor ---
    ("Portal do Fornecedor", "História", "Tela de cadastro de fornecedores", "Done", "Fábio Neri", -10, False, ""),
    ("Portal do Fornecedor", "História", "Tela de envio de notas fiscais", "Active", "Gabi Torres", 4, False, ""),
    ("Portal do Fornecedor", "Bug", "Upload falha com arquivos grandes", "Active", "Fábio Neri", -4, True, "Limite do servidor precisa ser ajustado pela infraestrutura"),
    ("Portal do Fornecedor", "Tarefa", "Revisão de segurança", "New", "", -6, False, ""),
    ("Portal do Fornecedor", "Tarefa", "Documentação para fornecedores", "New", "Gabi Torres", 12, False, ""),
    ("Portal do Fornecedor", "Tarefa", "Go-live piloto", "New", "Fábio Neri", 30, False, ""),
]

ATAS = {
    "reuniao_2026-10-14.txt": """ATA DE REUNIÃO - 14/10/2026
Assunto: Comitê semanal - Migração CRM
Participantes: Ana Souza, Bruno Lima, Carla Dias

Decisões:
- Manter a data de go-live, desde que a integração com o ERP seja iniciada até o fim do mês.
- Bruno vai escalar o erro de importação de contatos para o fornecedor.

Pendências:
- Ana: finalizar o plano de rollback até sexta.
- Carla: confirmar a agenda de treinamento com a equipe comercial.

Riscos:
- Atraso do fornecedor pode comprometer os testes de aceitação.
""",
    "reuniao_2026-10-15.txt": """ATA DE REUNIÃO - 15/10/2026
Assunto: Alinhamento Service Desk
Participantes: Diego Rocha, Elisa Prado

Decisões:
- Priorizar a migração dos chamados abertos antes de criar a base de conhecimento.

Pendências:
- Diego: concluir migração de chamados (atrasada).
- Elisa: validar fluxos de aprovação com a área financeira.
- Definir responsável pela base de conhecimento (ainda sem dono).
""",
    "email_infra_portal.txt": """De: Gabi Torres
Assunto: Portal do Fornecedor - limite de upload

Olá, pessoal da infraestrutura. O upload de notas fiscais falha acima de 10 MB.
Precisamos que o limite do servidor seja ajustado para 50 MB. Esse item está
bloqueando a tela de envio de notas fiscais e o piloto com os fornecedores.
Conseguem priorizar esta semana?
""",
}


def main():
    itens = []
    for i, (proj, tipo, titulo, estado, resp, dias, bloq, motivo) in enumerate(ITENS, start=101):
        itens.append({
            "id": i, "projeto": proj, "tipo": tipo, "titulo": titulo, "estado": estado,
            "responsavel": resp, "prazo": (HOJE + timedelta(days=dias)).isoformat(),
            "bloqueado": bloq, "motivo_bloqueio": motivo,
        })
    Path("dados_falsos").mkdir(exist_ok=True)
    Path("dados_falsos/itens.json").write_text(
        json.dumps(itens, ensure_ascii=False, indent=2), encoding="utf-8")

    Path("entrada").mkdir(exist_ok=True)
    for nome, texto in ATAS.items():
        Path("entrada", nome).write_text(texto, encoding="utf-8")
    print(f"{len(itens)} itens e {len(ATAS)} materiais de exemplo criados.")


if __name__ == "__main__":
    main()
