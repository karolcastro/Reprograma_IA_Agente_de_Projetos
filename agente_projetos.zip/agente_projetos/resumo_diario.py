"""
resumo_diario.py
----------------
Monta o "Bom dia, Projetos" (resumo por regras, sem IA e sem custo) e envia ao
SEU Telegram. Roda sozinho toda manhã pelo GitHub Actions (veja a pasta .github).

Rodar na mão:  python resumo_diario.py
"""

import os
from datetime import date

import status

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:  # no GitHub Actions não precisamos do .env
    pass

import canal_telegram

SEMAFORO = {"verde": "🟢", "amarelo": "🟡", "vermelho": "🔴"}


def montar_resumo() -> str:
    itens = status.carregar_itens()
    linhas = [f"Bom dia! Resumo dos projetos em {date.today():%d/%m/%Y}", ""]
    for nome in sorted({i["projeto"] for i in itens}):
        r = status.analisar([i for i in itens if i["projeto"] == nome])
        linhas.append(f"{SEMAFORO[r['semaforo']]} {nome}: {r['concluidos']}/{r['total']} concluídos, "
                      f"{len(r['atrasados'])} atrasados, {len(r['bloqueados'])} bloqueados")
        if r["bloqueados"]:
            b = r["bloqueados"][0]
            linhas.append(f"   Gargalo: #{b['id']} {b['titulo']} ({b['motivo_bloqueio']})")
        if r["proximos_passos"]:
            p = r["proximos_passos"][0]
            linhas.append(f"   Próximo prazo: {p['titulo']} em {p['prazo']}")
    return "\n".join(linhas)


def main():
    texto = montar_resumo()
    print(texto)
    chat = os.getenv("TELEGRAM_CHAT_ID")
    if not (os.getenv("TELEGRAM_BOT_TOKEN") and chat):
        print("\n(Simulação: Telegram não configurado, nada foi enviado.)")
        return
    canal_telegram.enviar(chat, texto)
    print("\nEnviado ao Telegram.")


if __name__ == "__main__":
    main()
